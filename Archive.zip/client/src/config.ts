interface Config {
  apiBaseUrl: string;
  frontendUrl: string;
}

const config: Config = {
  apiBaseUrl: process.env.REACT_APP_API_BASE_URL || 'http://localhost:5001/api',
  frontendUrl: process.env.REACT_APP_FRONTEND_URL || 'http://localhost:3000',
};

export default config; 